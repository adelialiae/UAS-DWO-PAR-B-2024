<!-- auth.php -->
<?php
// auth.php
session_start();
include 'koneksi.php'; // Replace with your DB connection setup

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    // echo $username;
    $password = $_POST['password'];

    // Query the database for user credentials
    $stmt = $conn->prepare("SELECT id, username, password FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    // print_r($result);
    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();
        // print_r($user);
        print($user['password']."\n");
        print($password."\n");

        // Verify the password
        // if (password_verify($password, $user['password'])) {
        //     // Set session variables
        //     echo "Masuk";
            // $_SESSION['user_id'] = $user['id'];
            // $_SESSION['username'] = $user['username'];
            // echo $user['id'];
            // // Redirect to home
            // header('Location: home.php');
            // exit;

        // if ($password == $user['password']){
        //     $_SESSION['user_id'] = $user['id'];
        //     $_SESSION['username'] = $user['username'];
            // echo $user['id'];
        if (password_verify($password, $user['password'])) {
                // Set session variables
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];    
            
            // Redirect to the original requested page if it exists
            $redirect_url = $_SESSION['redirect_to'] ?? 'dashboard.php';
            unset($_SESSION['redirect_to']);
            header("Location: $redirect_url");
            exit;
            
            // Redirect to home
            // header('Location: home.php');
            // exit;

        }

        else {
            $error = "Invalid username or password.";
        }
    } else {
        $error = "Invalid username or password.";
    }

    $stmt->close();
}
?>