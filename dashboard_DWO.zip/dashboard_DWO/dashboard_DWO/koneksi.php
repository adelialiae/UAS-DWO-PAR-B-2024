<?php
$host = 'localhost'; // Ganti dengan host database Anda
$username = 'root'; // Ganti dengan username database Anda
$password = ''; // Ganti dengan password database Anda
$db_sales = 'dw_sales'; // Nama database untuk penjualan
$db_purchasing = 'dw_purchasing'; // Nama database untuk pembelian

// Koneksi ke database dw_sales
$conn_sales = new mysqli($host, $username, $password, $db_sales);
if ($conn_sales->connect_error) {
    die("Koneksi gagal ke dw_sales: " . $conn_sales->connect_error);
}

// Koneksi ke database dw_purchasing
$conn_purchasing = new mysqli($host, $username, $password, $db_purchasing);
if ($conn_purchasing->connect_error) {
    die("Koneksi gagal ke dw_purchasing: " . $conn_purchasing->connect_error);
}
?>