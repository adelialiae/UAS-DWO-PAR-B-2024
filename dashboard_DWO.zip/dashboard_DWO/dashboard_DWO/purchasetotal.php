<?php
$dbHost = "localhost";
$dbDatabase = "dw_purchasing";
$dbUser = "root";
$dbPassword = "";

// Koneksi ke database
$mysqli = mysqli_connect($dbHost, $dbUser, $dbPassword, $dbDatabase);

// Query untuk mendapatkan TotalCost per Tahun
$sql_year = "SELECT t.tahun AS Year, SUM(fp.TotalCost) AS TotalCost
             FROM factpurchasing fp
             JOIN dimdate t ON fp.DateID = t.DateID
             GROUP BY t.tahun
             ORDER BY t.tahun ASC";
$result_year = mysqli_query($mysqli, $sql_year);

// Ambil data untuk Card dan Chart
$year_data = [];
$cards = [];
while ($row = mysqli_fetch_assoc($result_year)) {
    $year = (int)$row['Year'];
    $totalCost = (float)$row['TotalCost'];
    $year_data[] = [$year, $totalCost];
    $cards[] = ['Year' => $year, 'TotalCost' => number_format($totalCost, 2)];
}

// Encode data ke JSON untuk Highcharts
$json_year_data = json_encode($year_data);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <!-- External CSS -->
   <link rel="stylesheet" href="style.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <!-- Highcharts -->
    <script src="https://code.highcharts.com/highcharts.js"></script>
    <script src="https://code.highcharts.com/modules/exporting.js"></script>
    <script src="https://code.highcharts.com/modules/export-data.js"></script>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<!-- Highcharts CDN -->
<script src="https://code.highcharts.com/highcharts.js"></script>
    <script src="https://code.highcharts.com/modules/series-label.js"></script>
    <script src="https://code.highcharts.com/modules/exporting.js"></script>
    <script src="https://code.highcharts.com/modules/export-data.js"></script>
    <script src="https://code.highcharts.com/modules/accessibility.js"></script>


    <style>
        body {
            background-color: #f3f0ff;
        }
        .container {
    margin-top: 20px;
        }
        .card {
            background: #ffffff;
    border-radius: 5px;
    padding: 5px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    border-left: 5px solid #4338CA; /* Menambahkan border kiri dengan warna ungu */
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 10px;
    margin: 8px;
        }
        .card-title {
            font-size: 1.2rem;
            color: #4338CA;
            text-align: left;
            font-weight: bold;
        }
        .card-text {
            font-size: 1.5rem;
            font-weight: bold;
            text-align: left;
            color: #2c3e50;
        }
        h2 {
            font-size: 1.5rem;
            font-weight: bold;
            color: #4338CA;
            text-align: left;
            margin-bottom: 20px;
        }
        header {
    background-color:rgb(247, 246, 255);
    color: #2c3e50;
    padding: 10px;
    text-align: left;
    font-size: 18px;
}

    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <h2>UAS DWO</h2>
        <ul>
        <li><a href="dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
            <li><a href="salesterritory.php"><i class="fas fa-chart-area"></i> Sales Territory</a></li>
            <li><a href="salesorder.php"><i class="fas fa-chart-line"></i> Sales Order</a></li>
            <li><a href="salesproduk.php"><i class="fas fa-chart-pie"></i> Sales Product</a></li>
            <li><a href="purchasetotal.php"><i class="fas fa-shopping-cart"></i>Purchasing</a></li>
            <li><a href="purchaseproduct.php"><i class="fas fa-box"></i>Product Stock</a></li>
            <li><a href="olap.php"><i class="fab fa-dropbox"></i> OLAP</a></li>
        </ul>
        <div class="logout">
            <button onclick="logout()"><i class="fas fa-sign-out-alt"></i> Logout</button>
        </div>
    </div>


    <!-- Content Section -->
    <div class="content">
    <h2>Total Pembelian Berdasarkan Tahun</h2>
            <!-- Section Card -->
            <div class="row">
    <?php 
    if (!empty($cards)):
    foreach ($cards as $card): ?>
           <div class="col-md-4 col-sm-6">
                        <div class="card text-center">
                            <div class="card-body">
            <h5 class="card-title"><?php echo $card['Year']; ?></h5>
            <p class="card-text">$<?php echo $card['TotalCost']; ?></p>
            </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="col-12">
                <p class="text-center text-danger">Data tidak tersedia.</p>
            </div>
        <?php endif; ?>
    </div>

    <!-- Chart -->
    <div id="container" style="width: 100%; height: 500px;" class="mt-5"></div>
    </div>

<script type="text/javascript">
    // Data dari PHP (Total Cost per Tahun)
    const yearData = <?php echo $json_year_data; ?>;

    // Membuat Area Chart
    Highcharts.chart('container', {
        chart: {
            type: 'area'
        },
        title: {
            text: 'Total Cost Pembelian Berdasarkan Tahun'
        },
        subtitle: {
            text: 'Source: dw_purchasing Database'
        },
        xAxis: {
            title: { text: 'Tahun' },
            categories: yearData.map(item => item[0]), // Tahun
            labels: { rotation: -45 }
        },
        yAxis: {
            title: {
                text: 'Total Pembelian (USD)'
            }
        },
        tooltip: {
            pointFormat: 'Total Pembelian: <b>${point.y:,.2f}</b>'
        },
        plotOptions: {
            area: {
                marker: {
                    enabled: true,
                    symbol: 'circle',
                    radius: 4
                },
                fillOpacity: 0.5
            }
        },
        series: [{
            name: 'Total Pembelian',
            data: yearData.map(item => item[1]), // Total Cost
            color: '#28a745'
        }]
    });
</script>

</body>
</html>
