<?php
// Koneksi ke database
$host = 'localhost';
$username = 'root';
$password = '';
$db_sales = 'dw_sales';

$mysqli = new mysqli($host, $username, $password, $db_sales);

// Cek koneksi
if ($mysqli->connect_error) {
    die("Koneksi gagal: " . $mysqli->connect_error);
}

// Query SQL untuk menghitung jumlah produk terjual per kategori
$sql = "SELECT dp.ProductCategory AS Category, 
               COUNT(fs.ProductID) AS TotalSold
        FROM fact_sales fs
        JOIN dimproduct dp ON fs.ProductID = dp.ProductID
        GROUP BY dp.ProductCategory
        ORDER BY COUNT(fs.ProductID) DESC";

$result = $mysqli->query($sql);

// Format data untuk chart dan card
$data = [];
$cards = [];
while ($row = $result->fetch_assoc()) {
    $category = $row['Category'];
    $totalSold = (int)$row['TotalSold'];
    $data[] = [$category, $totalSold];
    $cards[] = [
        'Category' => $category,
        'TotalSold' => number_format($totalSold)
    ];
}

// JSON untuk chart
$categories_json = json_encode(array_column($data, 0)); // Kategori
$data_json = json_encode(array_column($data, 1));       // Total produk terjual
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Total Produk Terjual per Product Category</title>
    <!-- External CSS -->
    <link rel="stylesheet" href="style.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <!-- Highcharts -->
    <script src="https://code.highcharts.com/highcharts.js"></script>
    <script src="https://code.highcharts.com/modules/exporting.js"></script>
    <script src="https://code.highcharts.com/modules/export-data.js"></script>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

    <style>
        body {
            background-color: #f3f0ff;
        }
        .container {
            margin-top: 20px;
        }
        .card {
            background: #ffffff;
            border-radius: 5px;
            padding: 5px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-left: 5px solid #4338CA;
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 10px;
            margin: 8px;
        }
        .card-title {
            font-size: 1.2rem;
            color: #4338CA;
            text-align: left;
            font-weight: bold;
        }
        .card-text {
            font-size: 1.5rem;
            font-weight: bold;
            text-align: left;
            color: #2c3e50;
        }
        h2 {
            font-size: 1.5rem;
            font-weight: bold;
            color: #4338CA;
            text-align: left;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
<body class="dashboard-body">
    <!-- Sidebar -->
    <div class="sidebar">
    <h2>UAS DWO</h2>
    <ul>
    <li><a href="dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
            <li><a href="salesterritory.php"><i class="fas fa-chart-area"></i> Sales Territory</a></li>
            <li><a href="salesorder.php"><i class="fas fa-chart-line"></i> Sales Order</a></li>
            <li><a href="salesproduk.php"><i class="fas fa-chart-pie"></i> Sales Product</a></li>
            <li><a href="purchasetotal.php"><i class="fas fa-shopping-cart"></i>Purchasing</a></li>
            <li><a href="purchaseproduct.php"><i class="fas fa-box"></i>Product Stock</a></li>
        <li><a href="olap.php"><i class="fab fa-dropbox"></i> OLAP</a></li>
    </ul>
    <div class="logout">
        <button onclick="logout()"><i class="fas fa-sign-out-alt"></i> Logout</button>
    </div>
</div>
 <!-- Content Section -->
 <div class="content">
    <h2>Total Produk Terjual per Product Category</h2>
    <!-- Cards -->
    <div class="row">
        <?php if (!empty($cards)): ?>
            <?php foreach ($cards as $card): ?>
                <div class="col-md-4 col-sm-6">
                    <div class="card text-center">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo htmlspecialchars($card['Category']); ?></h5>
                            <p class="card-text"><?php echo htmlspecialchars($card['TotalSold']); ?> Terjual</p>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="col-12">
                <p class="text-center text-danger">Data tidak tersedia.</p>
            </div>
        <?php endif; ?>
    </div>

    <!-- Section Chart -->
    <div id="container" style="width: 100%; height: 500px;" class="mt-5"></div>
</div>


<script type="text/javascript">
    // Data dari PHP
    const categories = <?php echo $categories_json; ?>;
    const salesData = <?php echo $data_json; ?>;

    // Membuat Bar Chart
    Highcharts.chart('container', {
        chart: {
            type: 'column'
        },
        title: {
            text: 'Total Produk Terjual per Product Category'
        },
        subtitle: {
            text: 'Source: dw_sales database'
        },
        xAxis: {
            categories: categories,
            crosshair: true,
            title: {
                text: 'Product Category'
            }
        },
        yAxis: {
            min: 0,
            title: {
                text: 'Total Produk Terjual (Qty)'
            }
        },
        tooltip: {
            valueSuffix: ' Terjual'
        },
        plotOptions: {
            column: {
                pointPadding: 0.2,
                borderWidth: 0
            }
        },
        series: [{
            name: 'Total Sold',
            colorByPoint: true,
            data: salesData
        }]
    });
</script>

</body>
</html>
