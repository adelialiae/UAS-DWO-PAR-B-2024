<?php
include 'koneksi.php'; // Koneksi ke database

// Query untuk mengambil total penjualan berdasarkan kategori produk
$sql = "SELECT p.ProductCategory AS kategori, SUM(f.SalesAmount) AS total_penjualan
        FROM fact_sales f
        JOIN dimproduct p ON f.ProductID = p.ProductID
        GROUP BY p.ProductCategory";
$result = $conn_sales->query($sql);

// Simpan hasil ke dalam array
$product_sales = [];
while ($row = $result->fetch_assoc()) {
    $product_sales[] = $row;
}

// Data untuk Pie Chart
$data_pie_chart = [];
foreach ($product_sales as $sales) {
    $data_pie_chart[] = [
        'name' => $sales['kategori'],
        'y' => (float) $sales['total_penjualan'],
        'drilldown' => $sales['kategori']
    ];
}
$json_pie_chart = json_encode($data_pie_chart);

// CHART KEDUA (DRILL DOWN)

// Query untuk tahu total semua kategori
$sql = "SELECT p.ProductCategory kategori, SUM(f.SalesAmount) AS tot_kat
        FROM fact_sales f
        JOIN dimproduct p ON p.ProductID = f.ProductID
        GROUP BY kategori";
$result_tot = $conn_sales->query($sql);
$tot_all_kat = [];
while ($row = $result_tot->fetch_assoc()) {
    $tot_all_kat[$row['kategori']] = $row['tot_kat'];
}

// Query untuk detail penjualan per bulan berdasarkan kategori
$sql = "SELECT p.ProductCategory kategori, t.bulan, SUM(f.SalesAmount) AS pendapatan_kat
        FROM fact_sales f
        JOIN dimproduct p ON p.ProductID = f.ProductID
        JOIN dimtime t ON t.TimeID = f.TimeID
        GROUP BY p.ProductCategory, t.bulan";
$result_detail = $conn_sales->query($sql);

// Format data untuk drilldown
$drilldown_data = [];
while ($row = $result_detail->fetch_assoc()) {
    $kategori = $row['kategori'];
    $bulan = $row['bulan'];
    $pendapatan = (float) $row['pendapatan_kat'];
    
    if (!isset($drilldown_data[$kategori])) {
        $drilldown_data[$kategori] = [];
    }
    $drilldown_data[$kategori][] = [$bulan, $pendapatan];
}

$final_drilldown = [];
foreach ($drilldown_data as $key => $values) {
    $final_drilldown[] = [
        'name' => $key,
        'id' => $key,
        'data' => $values
    ];
}
$json_drilldown_data = json_encode($final_drilldown);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <!-- External CSS -->
    <link rel="stylesheet" href="style.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <!-- Highcharts -->
    <script src="https://code.highcharts.com/highcharts.js"></script>
    <script src="https://code.highcharts.com/modules/exporting.js"></script>
    <script src="https://code.highcharts.com/modules/export-data.js"></script>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

    <style>
        body {
            background-color: #f3f0ff;
        }
        .container {
    margin-top: 20px;
        }
        .card {
            background: #ffffff;
    border-radius: 5px;
    padding: 5px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    border-left: 5px solid #4338CA; /* Menambahkan border kiri dengan warna ungu */
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 10px;
    margin: 8px;
        }
        .card-title {
            font-size: 1.2rem;
            color: #4338CA;
            text-align: left;
            font-weight: bold;
            text-transform: none;
        }
        .card-text {
            font-size: 1.5rem;
            font-weight: bold;
            text-align: left;
            color: #2c3e50;
        }
        h2 {
            font-size: 1.5rem;
            font-weight: bold;
            color: #4338CA;
            text-align: left;
            margin-bottom: 20px;
        }
        header {
    background-color:rgb(247, 246, 255);
    color: #2c3e50;
    padding: 10px;
    text-align: left;
    font-size: 18px;
}

    </style>

</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <h2>UAS DWO</h2>
        <ul>
        <li><a href="dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
            <li><a href="salesterritory.php"><i class="fas fa-chart-area"></i> Sales Territory</a></li>
            <li><a href="salesorder.php"><i class="fas fa-chart-line"></i> Sales Order</a></li>
            <li><a href="salesproduk.php"><i class="fas fa-chart-pie"></i> Sales Product</a></li>
            <li><a href="purchasetotal.php"><i class="fas fa-shopping-cart"></i>Purchasing</a></li>
            <li><a href="purchaseproduct.php"><i class="fas fa-box"></i>Product Stock</a></li>
            <li><a href="olap.php"><i class="fab fa-dropbox"></i> OLAP</a></li>
        </ul>
        <div class="logout">
            <button onclick="logout()"><i class="fas fa-sign-out-alt"></i> Logout</button>
        </div>
    </div>



    <div class="content">
    <!-- Judul Halaman -->
    <h2>Product Sales by Category</h2>

    <!-- Section Card -->
    <div class="row">
    <?php 
    // Loop data untuk menampilkan card
    if (!empty($product_sales)): 
        foreach ($product_sales as $sales): ?>
        <div class="col-md-4 col-sm-6">
            <div class="card text-center">
                <div class="card-body">
                    <!-- Hapus strtoupper agar teks tampil sesuai format asli -->
                    <h5 class="card-title"><?php echo $sales['kategori']; ?></h5>
                    <p class="card-text"><?php echo number_format($sales['total_penjualan'], 0); ?></p>
                </div>
            </div>
        </div>
    <?php endforeach;?>
    <?php else: ?>
        <div class="col-12">
            <p class="text-center text-danger">Data tidak tersedia.</p>
        </div>
    <?php endif; ?>
</div>

<!-- Section Pie Chart -->
<div id="container" style="width: 100%; height: 500px;" class="mt-5">
    <div id="piechart"></div>
</div>

<!-- Highcharts Pie Chart dengan Drilldown -->
<script type="text/javascript">
document.addEventListener('DOMContentLoaded', function () {
    Highcharts.chart('piechart', {
        chart: {
            type: 'pie'
        },
        title: {
            text: 'Persentase Penjualan per Kategori'
        },
        subtitle: {
            text: 'Klik kategori untuk melihat detail penjualan per bulan'
        },
        accessibility: {
            announceNewData: {
                enabled: true
            }
        },
        plotOptions: {
            series: {
                dataLabels: {
                    enabled: true,
                    format: '{point.name}: {point.percentage:.1f}%'
                }
            }
        },
        tooltip: {
            headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
            pointFormat: '<span style="color:{point.color}">{point.name}</span>: <b>{point.y:.0f}</b> total penjualan<br/>'
        },
        series: [{
            name: "Kategori",
            colorByPoint: true,
            data: <?php echo $json_pie_chart; ?>
        }],
        drilldown: {
            series: <?php echo $json_drilldown_data; ?>
        }
    });
});
</script>

<!-- Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
