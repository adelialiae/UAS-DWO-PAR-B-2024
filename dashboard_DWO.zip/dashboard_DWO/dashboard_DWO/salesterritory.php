<?php
// Koneksi ke database
$dbHost = "localhost";
$dbDatabase = "dw_sales";
$dbUser = "root";
$dbPassword = "";

$mysqli = mysqli_connect($dbHost, $dbUser, $dbPassword, $dbDatabase);

// Cek koneksi
if (!$mysqli) {
    die("Connection failed: " . mysqli_connect_error());
}

// Query SQL untuk mendapatkan data penjualan berdasarkan SalesTerritory
$sql = "SELECT 
            t.TerritoryName, 
            SUM(f.SalesAmount) AS TotalSales 
        FROM 
            dimsalesterritory t
        JOIN 
            fact_sales f ON t.TerritoryID = f.TerritoryID
        GROUP BY 
            t.TerritoryName
        ORDER BY 
            TotalSales DESC;";

$result = mysqli_query($mysqli, $sql);

// Format data untuk Highcharts dan Card
$categories = [];
$data = [];
$sales_territory = [];

while ($row = mysqli_fetch_assoc($result)) {
    $categories[] = $row['TerritoryName']; 
    $data[] = (float)$row['TotalSales'];
    $sales_territory[] = $row;
}

$categories_json = json_encode($categories);
$data_json = json_encode($data);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <!-- External CSS -->
    <link rel="stylesheet" href="style.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <!-- Highcharts -->
    <script src="https://code.highcharts.com/highcharts.js"></script>
    <script src="https://code.highcharts.com/modules/exporting.js"></script>
    <script src="https://code.highcharts.com/modules/export-data.js"></script>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

    <style>
        body {
            background-color: #f3f0ff;
        }
        .container {
    margin-top: 20px;
        }
        .card {
            background: #ffffff;
    border-radius: 5px;
    padding: 5px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    border-left: 5px solid #4338CA; /* Menambahkan border kiri dengan warna ungu */
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 10px;
    margin: 8px;
        }
        .card-title {
            font-size: 1.2rem;
            color: #4338CA;
            text-align: left;
            font-weight: bold;
            text-transform: none;
        }
        .card-text {
            font-size: 1.5rem;
            font-weight: bold;
            text-align: left;
            color: #2c3e50;
        }
        h2 {
            font-size: 1.5rem;
            font-weight: bold;
            color: #4338CA;
            text-align: left;
            margin-bottom: 20px;
        }
        header {
    background-color:rgb(247, 246, 255);
    color: #2c3e50;
    padding: 10px;
    text-align: left;
    font-size: 18px;
}

    </style>

</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <h2>UAS DWO</h2>
        <ul>
        <li><a href="dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
            <li><a href="salesterritory.php"><i class="fas fa-chart-area"></i> Sales Territory</a></li>
            <li><a href="salesorder.php"><i class="fas fa-chart-line"></i> Sales Order</a></li>
            <li><a href="salesproduk.php"><i class="fas fa-chart-pie"></i> Sales Product</a></li>
            <li><a href="purchasetotal.php"><i class="fas fa-shopping-cart"></i>Purchasing</a></li>
            <li><a href="purchaseproduct.php"><i class="fas fa-box"></i>Product Stock</a></li>
            <li><a href="olap.php"><i class="fab fa-dropbox"></i> OLAP</a></li>
        </ul>
        <div class="logout">
            <button onclick="logout()"><i class="fas fa-sign-out-alt"></i> Logout</button>
        </div>
    </div>
    <!-- Content Section -->
    <div class="content">
    <h2>Sales by Territory</h2>
    <!-- Section Card -->
    <div class="row">
        <?php 
        if (!empty($sales_territory)):
            foreach ($sales_territory as $territory): ?>
            <div class="col-md-4 col-sm-6">
                <div class="card text-center">
                    <div class="card-body">
                        <!-- Hapus strtoupper agar teks sesuai dengan format aslinya -->
                        <h5 class="card-title"><?php echo $territory['TerritoryName']; ?></h5>
                        <p class="card-text">$<?php echo number_format($territory['TotalSales'], 0); ?></p>
                    </div>
                </div>
            </div>
        <?php endforeach; 
        else: ?>
            <div class="col-12">
                <p class="text-center text-danger">Data tidak tersedia.</p>
            </div>
        <?php endif; ?>
    </div>

    <!-- Section Chart -->
    <div id="container" style="width: 100%; height: 500px;" class="mt-5"></div>
</div>


    <!-- Highcharts Script -->
    <script type="text/javascript">
        Highcharts.chart('container', {
            chart: {
                type: 'column'
            },
            title: {
                text: 'Total Sales by Sales Territory'
            },
            subtitle: {
                text: 'Source: dw_sales database'
            },
            xAxis: {
                categories: <?php echo $categories_json; ?>,
                crosshair: true,
                title: {
                    text: 'Sales Territory'
                }
            },
            yAxis: {
                min: 0,
                title: {
                    text: 'Total Sales (USD)'
                }
            },
            tooltip: {
                valueSuffix: ' USD'
            },
            plotOptions: {
                column: {
                    pointPadding: 0.2,
                    borderWidth: 0
                }
            },
            series: [{
                name: 'Total Sales',
                colorByPoint: true,
                data: <?php echo $data_json; ?>
            }]
        });
    </script>

    <!-- Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
