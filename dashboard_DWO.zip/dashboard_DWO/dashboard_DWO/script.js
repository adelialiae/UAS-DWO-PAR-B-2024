// Function to show the register form
function showRegister() {
    console.log("Navigasi ke halaman Register");
    document.getElementById("login-form").style.display = "none";
    document.getElementById("register-form").style.display = "block";
}

// Function to show the login form
function showLogin() {
    console.log("Navigasi ke halaman Login");
    document.getElementById("register-form").style.display = "none";
    document.getElementById("login-form").style.display = "block";
}

// Function for Login
function login() {
    const username = document.getElementById("login-username").value;
    const password = document.getElementById("login-password").value;

    if (username && password) {
        console.log(`Login berhasil untuk user: ${username}`);
        alert("Login berhasil! Mengarahkan ke dashboard...");
        window.location.href = "dashboard.php"; // Redirect ke Dashboard
    } else {
        console.log("Username atau Password kosong!");
        alert("Username dan Password harus diisi!");
    }
}

// Function for Register
function register() {
    const username = document.getElementById("register-username").value;
    const password = document.getElementById("register-password").value;

    if (username && password) {
        console.log(`Registrasi berhasil untuk user: ${username}`);
        alert("Registrasi berhasil! Silakan Login.");
        showLogin(); // Kembali ke form login
    } else {
        console.log("Username atau Password kosong saat registrasi!");
        alert("Username dan Password harus diisi!");
    }
}

// Function for Logout
function logout() {
    console.log("User berhasil logout");
    alert("Anda berhasil logout. Kembali ke halaman login.");
    window.location.href = "index.html"; // Redirect ke halaman login
}
